﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class text : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
if(!IsPostBack)
{
    MultiView1.ActiveViewIndex = 0;
    Calendar1.Visible = false;
    DropDownList1.Items.Add("Select");
    DropDownList1.Items.Add("Child Specialist");
    DropDownList1.Items.Add("Ladies Specialist");
    DropDownList1.Items.Add("Heart Specialist");
    DropDownList1.Items.Add("Pathology Specialist");
    DropDownList1.Items.Add("Neurology Specialist");
    DropDownList1.Items.Add("Bone and Joint Specialist");
}
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList2.Items.Clear();
        DropDownList3.Items.Clear();
        switch (DropDownList1.SelectedIndex)
        {
            case 0:
                DropDownList3.Items.Add("  ");
                break;
            case 1:
                DropDownList3.Items.Add("500");
                break;

            case 2:
                DropDownList3.Items.Add("500");
                break;

            case 3:
                DropDownList3.Items.Add("700");
                break;

            case 4:
                DropDownList3.Items.Add("800");
                break;

            case 5:
                DropDownList3.Items.Add("900");
                break;

            case 6:
                DropDownList3.Items.Add("1000");
                break;
        }
        switch (DropDownList1.SelectedIndex)
        {
            case 0:
                DropDownList2.Items.Add("  ");
                break;
            case 1:
                DropDownList2.Items.Add("CDoctor01");
                DropDownList2.Items.Add("CDoctor02");
                DropDownList2.Items.Add("CDoctor03");
                DropDownList2.Items.Add("CDoctor04");
                DropDownList2.Items.Add("CDoctor05");
                DropDownList2.Items.Add("CDoctor06");
                DropDownList2.Items.Add("CDoctor07");
                DropDownList2.Items.Add("CDoctor08");
                DropDownList2.Items.Add("CDoctor09");
                DropDownList2.Items.Add("CDoctor010");
                break;
            case 2:
                DropDownList2.Items.Add("LDoctor01");
                DropDownList2.Items.Add("LDoctor02");
                DropDownList2.Items.Add("LDoctor03");
                DropDownList2.Items.Add("LDoctor04");
                DropDownList2.Items.Add("LDoctor05");
                DropDownList2.Items.Add("LDoctor06");
                DropDownList2.Items.Add("LDoctor07");
                DropDownList2.Items.Add("LDoctor08");
                DropDownList2.Items.Add("LDoctor09");
                DropDownList2.Items.Add("LDoctor010");
                break;
            case 3:
                DropDownList2.Items.Add("HDoctor01");
                DropDownList2.Items.Add("HDoctor02");
                DropDownList2.Items.Add("HDoctor03");
                DropDownList2.Items.Add("HDoctor04");
                DropDownList2.Items.Add("HDoctor05");
                DropDownList2.Items.Add("HDoctor06");
                DropDownList2.Items.Add("HDoctor07");
                DropDownList2.Items.Add("HDoctor08");
                DropDownList2.Items.Add("HDoctor09");
                DropDownList2.Items.Add("HDoctor010");
                break;
            case 4:
                DropDownList2.Items.Add("PDoctor01");
                DropDownList2.Items.Add("PDoctor02");
                DropDownList2.Items.Add("PDoctor03");
                DropDownList2.Items.Add("PDoctor04");
                DropDownList2.Items.Add("PDoctor05");
                DropDownList2.Items.Add("PDoctor06");
                DropDownList2.Items.Add("PDoctor07");
                DropDownList2.Items.Add("PDoctor08");
                DropDownList2.Items.Add("PDoctor09");
                DropDownList2.Items.Add("PDoctor010");
                break;
            case 5:
                DropDownList2.Items.Add("NDoctor01");
                DropDownList2.Items.Add("NDoctor02");
                DropDownList2.Items.Add("NDoctor03");
                DropDownList2.Items.Add("NDoctor04");
                DropDownList2.Items.Add("NDoctor05");
                DropDownList2.Items.Add("NDoctor06");
                DropDownList2.Items.Add("NDoctor07");
                DropDownList2.Items.Add("NDoctor08");
                DropDownList2.Items.Add("NDoctor09");
                DropDownList2.Items.Add("NDoctor010");
                break;
            case 6:
                DropDownList2.Items.Add("BDoctor01");
                DropDownList2.Items.Add("BDoctor02");
                DropDownList2.Items.Add("BDoctor03");
                DropDownList2.Items.Add("BDoctor04");
                DropDownList2.Items.Add("BDoctor05");
                DropDownList2.Items.Add("BDoctor06");
                DropDownList2.Items.Add("BDoctor07");
                DropDownList2.Items.Add("BDoctor08");
                DropDownList2.Items.Add("BDoctor09");
                DropDownList2.Items.Add("BDoctor010");
                break;
        }

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
        Label2.Text = TextBox3.Text;
        Label4.Text = TextBox4.Text;
        Label6.Text = TextBox5.Text;
        Label15.Text = TextBox6.Text;
        Label17.Text = DropDownList1.SelectedItem.Text + "-" + DropDownList2.SelectedItem.Text;
        Label19.Text = TextBox1.Text;
        Label21.Text = DropDownList8.SelectedItem.Text;

    
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            string docinfo = Label17.Text;
            string date = Label19.Text + "-" + Label21.Text;
            string name = Label2.Text;
            int age = Convert.ToInt32(Label6.Text);
            string mob = Label4.Text;
            string add = Label15.Text;
            Connection obj = new Connection();
            int x = obj.Appoinment(docinfo, date, name, age, mob, add);
            if (x > 0)
            {
                Session["Balance"] = DropDownList3.SelectedItem.Text;
                Session["docinfo1"] = Label17.Text;
                Session["date"] = Label19.Text + "-" + Label21.Text; ;
                Session["name"] = Label2.Text;
                Session["age"] = Label6.Text;
                Session["mobile"] = Label4.Text;
                Session["address"] = Label15.Text;
                Response.Redirect("paynow.aspx");
            }
            else
            {
                Response.Write("<script>alert('Error')</script>");
            }
        }
        catch (System.UnauthorizedAccessException unauthorizedAccessException)
        {
            Response.Write("You Don't Have Permission");
        }
        catch (Exception)
        {
            Response.Write("An Error Occour");
        }
    }
    protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
        }
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToShortDateString();
        Calendar1.Visible = false;
    }
    protected void cncl_Click(object sender, EventArgs e)
    {
        Response.Redirect("text.aspx");
    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.IsOtherMonth || e.Day.IsToday|| e.Day.IsWeekend)
        {
            e.Day.IsSelectable = false;
           
        }
    }
}