﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string fb1 = name.Text;
        string fb2 = email.Text;
        string fb3 = subject.Text;
        string fb4 = message.Text;
        Connection obj = new Connection();
        int x = obj.feedback(fb1,fb2,fb3,fb4);
        if (x > 0)
        {
            name.Text = "";
            email.Text = "";
            subject.Text = "";
            message.Text = "";

        }
        else
        {
            Response.Write("<script>alert('Feedback not Sent')</script>");
        }
  
    }
}