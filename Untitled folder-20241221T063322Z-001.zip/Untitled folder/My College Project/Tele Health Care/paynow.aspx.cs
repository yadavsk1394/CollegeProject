﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class paynow : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
           
            Label21.Text = Session["docinfo1"].ToString();
            Label23.Text = Session["date"].ToString();
            Label13.Text = Session["name"].ToString();
            Label17.Text = Session["age"].ToString();
            Label15.Text = Session["mobile"].ToString();
            Label19.Text = Session["address"].ToString();
            Panel1.Visible = false;
            Panel2.Visible = false;
   }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedValue == "-1")
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
        }
        else  if (DropDownList1.SelectedValue == "credit")
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
        }
       else
        {
            Panel1.Visible = false;
            Panel2.Visible = true;
        }
    }
    protected void sk5_Click(object sender, EventArgs e)
    {
        //credit
        string sy1 = sk1.Text;
        string sy2 = sk2.SelectedItem.Text;
        string sy3 = sk3.Text;
        string sy4 = sk4.Text;
        Connection dc = new Connection();
        DataTable dt = dc.Checkcredit(sy4,sy3);
        if (dt.Rows.Count > 0)
        {
            Session["credit"] = sk4.Text;

            Response.Redirect("transaction.aspx");
        }
        else
        {

            Response.Write("Card is not valid");
        }
    }
    protected void sk11_Click(object sender, EventArgs e)
    {
        //debit
        string sy5 = sk5.Text;
        string sy6 = sk7.SelectedItem.Text;
        string sy7 = sk8.Text;
        string sy8 = sk9.Text;
        string sy9 = sk6.Text;
        string sy10 = sk10.Text;
        string sy11 = sk11.Text;
        Connection dc = new Connection();
        DataTable dt = dc.Checkdebit(sy7,sy10);
        if (dt.Rows.Count > 0)
        {
            Session["credit"] = sk8.Text;

            Response.Redirect("transaction1.aspx");
        }
        else
        {

            Response.Write("Card is not valid");
        }
    }
    protected void sk4_TextChanged(object sender, EventArgs e)
    {
      
    }
}