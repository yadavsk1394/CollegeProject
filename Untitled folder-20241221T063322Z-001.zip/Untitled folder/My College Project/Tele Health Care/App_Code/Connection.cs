﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;



public class Connection
{ SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter ad;
	public Connection()
	{
        con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;
	
	}
    public int feedback(string fb1, string fb2, string fb3, string fb4)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_feedback";
        cmd.Parameters.Add("@name", SqlDbType.VarChar, 40).Value = fb1;
        cmd.Parameters.Add("@email", SqlDbType.VarChar, 40).Value = fb2;
        cmd.Parameters.Add("@sub", SqlDbType.VarChar, 60).Value = fb3;
        cmd.Parameters.Add("@msg", SqlDbType.VarChar, 150).Value = fb4;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
    public int update( string fb2, string fb1)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_updoc";
        cmd.Parameters.Add("@email", SqlDbType.VarChar, 30).Value = fb2;
        cmd.Parameters.Add("@msg", SqlDbType.VarChar, 100).Value = fb1;
         con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
        
        
    public int Addpatient(string em, string nm, string ps, string re, string mb, string add, string gen, string age, string city)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_reg";
        cmd.Parameters.Add("@email", SqlDbType.VarChar, 100).Value = em;
        cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = nm;
        cmd.Parameters.Add("@password", SqlDbType.VarChar, 50).Value = ps;
        cmd.Parameters.Add("@repassword", SqlDbType.VarChar, 50).Value = re;
        cmd.Parameters.Add("@mobile", SqlDbType.VarChar, 10).Value = mb;
        cmd.Parameters.Add("@address", SqlDbType.VarChar, 100).Value = add;
        cmd.Parameters.Add("@gender", SqlDbType.VarChar, 10).Value = gen;
        cmd.Parameters.Add("@age", SqlDbType.Int).Value = age;
        cmd.Parameters.Add("@city", SqlDbType.VarChar, 50).Value = city;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }

    public int Appnt(string ue,string de,string stus)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_app1";
        cmd.Parameters.Add("@usere", SqlDbType.VarChar, 40).Value = ue;
        cmd.Parameters.Add("@doctore", SqlDbType.VarChar, 40).Value = de;
        cmd.Parameters.Add("@stus", SqlDbType.VarChar, 30).Value = stus;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
    public int Appoinment(string doctorinfo, string date, string name,int age,string mob,string add)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_appoinment";
        cmd.Parameters.Add("@Doctorinfo", SqlDbType.VarChar, 100).Value = doctorinfo;
        cmd.Parameters.Add("@bookingdate", SqlDbType.VarChar, 40).Value = date;
        cmd.Parameters.Add("@patientname", SqlDbType.VarChar, 20).Value = name;
        cmd.Parameters.Add("@age", SqlDbType.Int).Value = age;
        cmd.Parameters.Add("@mobileno", SqlDbType.VarChar, 10).Value = mob;
        cmd.Parameters.Add("@address", SqlDbType.VarChar, 100).Value = add;
           con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);

    }
    public int AddDoctor(string id, string pass, string fn, string ln, string gen, string str1, string mob, string email, string city, string exp, string str2)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_docreg";
        cmd.Parameters.Add("@Docid", SqlDbType.VarChar, 20).Value = id;
        cmd.Parameters.Add("@pass", SqlDbType.VarChar, 30).Value = pass;
        cmd.Parameters.Add("@fname", SqlDbType.VarChar, 30).Value = fn;
        cmd.Parameters.Add("@lname", SqlDbType.VarChar, 30).Value = ln;
        cmd.Parameters.Add("@gen", SqlDbType.VarChar, 10).Value = gen;
        cmd.Parameters.Add("@photo", SqlDbType.VarChar, 30).Value = str1;
        cmd.Parameters.Add("@mob", SqlDbType.VarChar, 30).Value = mob;
        cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = email;
        cmd.Parameters.Add("@city", SqlDbType.VarChar, 30).Value = city;
        cmd.Parameters.Add("@expe", SqlDbType.VarChar, 5).Value = exp;
        cmd.Parameters.Add("@spec", SqlDbType.VarChar, 50).Value = str2;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);

    }

    public int update1(string up1)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_update1";
        cmd.Parameters.Add("@up1", SqlDbType.VarChar, 500).Value = up1;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
    public int update2(string up2)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_update2";
        cmd.Parameters.Add("@up2", SqlDbType.VarChar, 500).Value = up2;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
    public int update3(string up3)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_update3";
        cmd.Parameters.Add("@up3", SqlDbType.VarChar, 500).Value = up3;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
    public int addbankaccount(string nm, string mno, string bid, string eid, string pass, string cpass, string tpass, string camnt, string add)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_bankregister";
        cmd.Parameters.Add("@nm", SqlDbType.VarChar, 30).Value = nm;
        cmd.Parameters.Add("@mno", SqlDbType.VarChar, 100).Value = mno;
        cmd.Parameters.Add("@bid", SqlDbType.VarChar, 100).Value = bid;
        cmd.Parameters.Add("@eid", SqlDbType.VarChar, 10).Value = eid;
        cmd.Parameters.Add("@pass", SqlDbType.VarChar, 30).Value = pass;
        cmd.Parameters.Add("@cpass", SqlDbType.VarChar, 4).Value = cpass;
        cmd.Parameters.Add("@tpass", SqlDbType.VarChar, 30).Value = tpass;
        cmd.Parameters.Add("@camnt", SqlDbType.VarChar, 30).Value = camnt;
        cmd.Parameters.Add("@add", SqlDbType.VarChar, 30).Value = add;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }


    public DataTable sky(int famt, string acno)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("update credit set amount='" + famt + "' where cardno='" + acno + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);

    }
    public DataTable sky1(int famt, string acno)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("update debit set amount='" + famt + "' where cardno='" + acno + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);

    }
    public DataTable Checkpatient(string em, string ps)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from reg where email='" + em + "' and pass='" + ps + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }

    public DataTable Checkcredit(string cdn, string mob)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from credit where cardno='" + cdn + "' and mobile='" + mob + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }
    public DataTable Checkdebit(string cdn, string dte)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from debit where cardno='" + cdn + "' and edate='" + dte + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }
    public DataTable Checkaccount(string credit)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from bank where credit='"+credit+"'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }
    public DataTable Checkaccount1(string acno)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from bankregister where bankid='" + acno + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }
    public DataTable Checkadmin(string em, string ps)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from adminlog where email='" + em + "' and pass='" + ps + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }
    public DataTable Checkdoc(string em, string ps)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from docreg where email='" + em + "' and pass='" + ps + "'", con);
        con.Close();
        ad.Fill(dt);
        return (dt);
    }

   
    public DataTable Checkdate(string date)
    {
        DataTable dt = new DataTable();
        con.Open();
        ad = new SqlDataAdapter("select * from appoinment where bookingdate='" + date + "'", con);
        con.Close();
        ad.Fill(dt); return (dt);
    }
    
    public int patientmsg(string dem, string pem, string sub, string msg, string str1)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "d_patientmsg";
        cmd.Parameters.Add("@docid", SqlDbType.VarChar, 20).Value = dem;
        cmd.Parameters.Add("@userid", SqlDbType.VarChar, 20).Value = pem;
        cmd.Parameters.Add("@sub", SqlDbType.VarChar, 40).Value = sub;
        cmd.Parameters.Add("@msg", SqlDbType.VarChar, 200).Value = msg;
        cmd.Parameters.Add("@data", SqlDbType.VarChar, 20).Value = str1;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }
    public int docmsg(string dem, string pem,  string msg, string str1)
    {
        int status = 0;
        cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_docmsg";
        cmd.Parameters.Add("@patid", SqlDbType.VarChar, 30).Value = dem;
        cmd.Parameters.Add("@docid", SqlDbType.VarChar, 30).Value = pem;
        cmd.Parameters.Add("@msg", SqlDbType.VarChar, 300).Value = msg;
        cmd.Parameters.Add("@data", SqlDbType.VarChar, 30).Value = str1;
        con.Open();
        status = cmd.ExecuteNonQuery();
        con.Close();
        return (status);
    }


    
}