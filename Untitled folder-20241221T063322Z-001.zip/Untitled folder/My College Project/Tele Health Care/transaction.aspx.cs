﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class transaction : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            Label21.Text = Session["docinfo1"].ToString();
            Label23.Text = Session["date"].ToString();
            Label13.Text = Session["name"].ToString();
            Label17.Text = Session["age"].ToString();
            Label15.Text = Session["mobile"].ToString();
            Label19.Text = Session["address"].ToString();
     
        TextBox1.Text = Session["credit"].ToString();
        TextBox2.Text = Session["Balance"].ToString();
        getamount(TextBox1.Text);
        }
    }

    private void getamount(string cdno)
    {
        string cs = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;

        string str;
        SqlConnection con = new SqlConnection(cs);
        con.Open();
        str = "select amount from credit where cardno='" + TextBox1.Text.Trim() + "'";
        SqlCommand com;
        com = new SqlCommand(str, con);
        SqlDataReader reader = com.ExecuteReader();
        if (reader.Read())
        {
            TextBox3.Text = reader["amount"].ToString();
            reader.Close();
            con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int a = Convert.ToInt32(TextBox3.Text) - Convert.ToInt32(TextBox2.Text);
        string cd = TextBox1.Text;
        Connection dc = new Connection();
        DataTable dt = dc.sky(a,cd);
          Response.Redirect("submitpayment.aspx");
       
    }
}