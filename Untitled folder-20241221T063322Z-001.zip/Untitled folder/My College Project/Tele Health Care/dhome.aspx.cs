﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class dhome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        email.Text = Session["Username"].ToString();
        TextBox2.Text = Session["Username"].ToString();
    }
         
    
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string dem = name.Text;
        string pem = email.Text;
        string msg = message.Text;
        string str1 = FileUpload1.FileName;
        if (FileUpload1.HasFile == true)
        {
            FileUpload1.SaveAs(Server.MapPath("mail file\\" + str1));
        }
        Connection obj = new Connection();
        int x = obj.docmsg(dem, pem, msg, str1);
        if (x > 0)
        {
            Label1.Text = "Your message has been successfully Sent";
            email.Text = "";
            message.Text = "";
            

        }
        else
        {
            Response.Write("<script>alert('Error')</script>");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string docid = TextBox2.Text;
        string docup = TextBox1.Text;
        Connection obj = new Connection();
        int x = obj.update( docid,docup);
        if (x > 0)
        {
            TextBox1.Text = "";

        }
        else
        {
            Response.Write("<script>alert('Feedback not Sent')</script>");
        }
    }
}