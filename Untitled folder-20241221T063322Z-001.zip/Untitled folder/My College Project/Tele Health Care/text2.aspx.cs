﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class text2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        name.Text = Session["Username"].ToString();
         if (!IsPostBack)
        {
            getmailname(name.Text);
            getmailname1(name.Text);
           }
    }
        private void getmailname(string mailid)
        {
            string cs = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            SqlDataAdapter da = new SqlDataAdapter("spgetmail", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            SqlParameter parammailid = new SqlParameter();
           parammailid.ParameterName  = "@patid";
            parammailid.Value = mailid;
            da.SelectCommand.Parameters.Add(parammailid);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gd1.DataSource = ds;
            gd1.DataBind();

        }
        private void getmailname1(string mailid)
        {
            string cs = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            SqlDataAdapter da = new SqlDataAdapter("spgetmail21", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            SqlParameter parammailid = new SqlParameter();
            parammailid.ParameterName = "@patid";
            parammailid.Value = mailid;
            da.SelectCommand.Parameters.Add(parammailid);
            DataSet ds = new DataSet();
            da.Fill(ds);
           GridView1.DataSource = ds;
           GridView1.DataBind();

        }
      }