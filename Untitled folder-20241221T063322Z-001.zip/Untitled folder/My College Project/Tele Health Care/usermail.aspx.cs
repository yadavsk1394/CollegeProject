﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class usermail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = Session["Useremail"].ToString();
        if (!IsPostBack)
        {
            getmailname1(Label1.Text);
            getmailname11(Label1.Text);
        }
    }
    private void getmailname1(string mailid1)
    {
        string cs = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);
        SqlDataAdapter da = new SqlDataAdapter("spgetmail1", con);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parammailid = new SqlParameter();
        parammailid.ParameterName = "@patid1";
        parammailid.Value = mailid1;
        da.SelectCommand.Parameters.Add(parammailid);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gd2.DataSource = ds;
        gd2.DataBind();

    }
    private void getmailname11(string mailid)
    {
        string cs = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);
        SqlDataAdapter da = new SqlDataAdapter("spgetmail11", con);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parammailid = new SqlParameter();
        parammailid.ParameterName = "@patid1";
        parammailid.Value = mailid;
        da.SelectCommand.Parameters.Add(parammailid);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gdd1.DataSource = ds;
        gdd1.DataBind();

    }   
}