﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Lab1.Text = Session["Username1"].ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string up1 = TextBox2.Text;

        Connection obj = new Connection();
        int x = obj.update1(up1);
        if (x > 0)
        {
            TextBox2.Text = "";
        }
        else
        {
            Response.Write("update unsuccessfull");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string up2 = TextBox3.Text;

        Connection obj = new Connection();
        int x = obj.update2(up2);
        if (x > 0)
        {
            TextBox3.Text = "";
        }
        else
        {
            Response.Write("update unsuccessfull");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
    }
}