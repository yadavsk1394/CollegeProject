﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class uhome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       lbl.Text = Session["Useremail"].ToString();
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        {
            string dem = email.Text;
            string pem = lbl.Text;
            string msg = message.Text;
            string sub = sub1.Text;
            string str1 = FileUpload1.FileName;
            if (FileUpload1.HasFile == true)
            {
                FileUpload1.SaveAs(Server.MapPath("mail file\\" + str1));
            }
            Connection obj = new Connection();
            int x = obj.patientmsg(dem, pem, sub, msg, str1);
            if (x > 0)
            {

              //  Label1.Text = "Your message has been successfully Sent";
                email.Text = "";
                message.Text = "";
                sub1.Text = "";
                    }
            else
            {
                Response.Write("<script>alert('Error')</script>");
            }

        }
    }
}