﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminapp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string umail = uemail.Text;
        string dmail = demail.Text;
        string stus = DropDownList1.SelectedItem.Text;
        Connection obj = new Connection();
        int x = obj.Appnt(umail,dmail,stus);
        if (x > 0)
        {
            uemail.Text = "";
            demail.Text = "";

        }
        else
        {
            Response.Write("<script>alert('Error')</script>");
        }
    }
}