﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Useremail"] != null)
            {
                lbl1.Text = Session["Useremail"].ToString();
                linkbtn.Text = "[LOGOUT]";
                lnk.Text = "USER PANEL";
            }
            if (Session["Username"] != null)
            {
                lbl1.Text = Session["Username"].ToString();
                linkbtn.Text = "[LOGOUT]";
                lnk.Text = "DOCTOR PANEL";
              
            }
            if (Session["Username1"] != null)
            {
                lbl1.Text = Session["Username1"].ToString();
                linkbtn.Text = "[LOGOUT]";
                lnk.Text = "ADMIN PANEL";

            }
        }

    }
    protected void lbsearch_Click(object sender, EventArgs e)
    {

    }
    protected void linkbtn_Click(object sender, EventArgs e)
    {
        if (Session["Useremail"] != null)
        {
            Session.Abandon();
            linkbtn.Text = "[LOGIN]";
            lbl1.Text = "";
            Response.Redirect("login.aspx");
        }
     
     else if (Session["Username"] != null)
        {
            Session.Abandon();
            linkbtn.Text = "[LOGIN]";
            lbl1.Text = "";
            Response.Redirect("login.aspx");
        }
       
        else if (Session["Username1"] != null)
        {
            Session.Abandon();
            linkbtn.Text = "[LOGIN]";
            lbl1.Text = "";
            Response.Redirect("login.aspx");
        }
        else
        {
            Response.Redirect("login.aspx");

        }
    }
    protected void lnk_Click(object sender, EventArgs e)
    {
        if (Session["Useremail"] != null)
         {
            Response.Redirect("uhome.aspx");
        }
       
        else if (Session["Username"] != null)
        {
            Response.Redirect("dhome.aspx");
        }
      
       else if (Session["Username1"] != null)
        {
            Response.Redirect("admin.aspx");
        }
        else
        {
            Response.Redirect("login.aspx");

        }
        
    }
}
