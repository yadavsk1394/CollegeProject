﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class userreg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string em = email.Text;
        string nm = name.Text;
        string ps = pass.Text;
        string re = rpass.Text;
        string mb = number.Text;       
        string add = Address.Text;
        string gen = Dd1.SelectedItem.Text;
        string age = age1.Text;
        string city = city1.Text; 

        Connection obj = new Connection();
        int x = obj.Addpatient(em, nm, ps, re, mb, add, gen, age, city);
        if (x > 0)
        {
            lbl.Text = "Registration Successful. Please Login";
            email.Text = "";
            name.Text = "";
            pass.Text = "";
            rpass.Text = "";
            number.Text = "";
            Address.Text = "";
            age1.Text = "";
            city1.Text = "";

        }
        else
        {
            Response.Write("<script>alert('Error')</script>");
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        email.Text = "";
        name.Text = "";
        pass.Text = "";
        rpass.Text = "";
        number.Text = "";
        Address.Text = "";
        age1.Text = "";
        city1.Text = "";
    }
}