﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class appconfirm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
        }
    private void getappointment(string cdno)
    {
        string cs = ConfigurationManager.ConnectionStrings["userConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);
        SqlDataAdapter da = new SqlDataAdapter("spapp", con);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parammailid = new SqlParameter();
        parammailid.ParameterName = "@fname";
        parammailid.Value = cdno;
        da.SelectCommand.Parameters.Add(parammailid);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        getappointment(username.Text);
    }
}
