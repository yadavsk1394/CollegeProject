﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class doctorlogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string em = email.Text;
        string ps = pass.Text;

        Connection dc = new Connection();
        DataTable dt = dc.Checkdoc(em, ps);
        if (dt.Rows.Count > 0)
        {
            Session["Username"] = email.Text;

            Response.Redirect("dhome.aspx");
        }
        else
        {

            Response.Write("Username or password is incorrect");
        }
    }
}