﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminlogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string em =email.Text;
        string ps = pass.Text;

        Connection dc = new Connection();
        DataTable dt = dc.Checkadmin(em, ps);
        if (dt.Rows.Count > 0)
        {
            Session["Username1"] = email.Text;

            Response.Redirect("admin.aspx");
        }
        else
        {

            Response.Write("<script>alert('Error')</script>");
        }
    }
}