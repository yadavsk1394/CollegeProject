﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class doctorup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string up3 = msg.Text;

        Connection obj = new Connection();
        int x = obj.update3(up3);
        if (x > 0)
        {
           msg.Text = "";
        }
        else
        {
            Response.Write("update unsuccessfull");
        }
    }
}