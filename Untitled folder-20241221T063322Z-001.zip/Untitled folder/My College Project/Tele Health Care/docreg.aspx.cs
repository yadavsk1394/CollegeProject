﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class docreg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        if (Fu1.HasFile)
        {
            string fileExtension = System.IO.Path.GetExtension(Fu1.FileName);
            if (fileExtension.ToLower() != ".jpg")
            {
                lblmsg.Text = "only files with .pdf extension are allowed";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                int fsize = Fu1.PostedFile.ContentLength;
                if (fsize > 2097152)
                {
                    lblmsg.Text = "File Size Minium 2MB";
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    Fu1.SaveAs(Server.MapPath("~/img/doc/" + Fu1.FileName));
                    lblmsg.Text = "File Uploaded Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }
            }
        }
        else
        {
            lblmsg.Text = "Please Select A file to be uploaded";
            lblmsg.ForeColor = System.Drawing.Color.Red;
        }
        string id = id1.Text;
        string pass = pass1.Text;
        string fn = rpass.Text;
        string ln = name.Text;
        string gen = Dd1.SelectedItem.Text;
        //Label2.Text = "ur profile is successful updated".ToUpper(); 

        string str1 = Fu1.FileName;
        if (Fu1.HasFile == true)
        {
            Fu1.SaveAs(Server.MapPath("img/doc\\" + str1));
        }
        string mob = mob1.Text;
        string email = email1.Text;
        string city = Address.Text;
        string exp = exp1.Text;
        string str2 = deg.Text;
        Connection obj = new Connection();
        int x = obj.AddDoctor(id, pass, fn, ln, gen, str1, mob, email, city, exp, str2);
        if (x > 0)
        {
            int d = 1000;
            Session["Balance"] = d;
            Response.Redirect("paynow1.aspx");
           
        }
        else
        {
            Response.Write("<script>alert('Error')</script>");
        }
  
    }
    protected void Cancel_Click(object sender, EventArgs e)
    {
        id1.Text = "";
        mob1.Text = "";
        email1.Text = "";
        name.Text = "";
        pass1.Text = "";
        rpass.Text = "";
        mob1.Text = "";
        Address.Text = "";
        exp1.Text = "";
        deg.Text = "";
    }
}